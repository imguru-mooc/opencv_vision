# 객체탐지 > 2025-04-14 1:24pm
https://universe.roboflow.com/tom-gaymg/-snvdj

Provided by a Roboflow user
License: CC BY 4.0

